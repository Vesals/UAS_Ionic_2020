import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-friends',
  templateUrl: './show-friends.page.html',
  styleUrls: ['./show-friends.page.scss'],
})
export class ShowFriendsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
